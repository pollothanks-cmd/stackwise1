# Plan: real accounts, sign-in, and paid Stripe tiers

This is a phased migration. Phase 1 ships a real, working sign-in + paywall this turn. Phase 2 (separate turn) migrates the in-memory inventory store to the database so data actually persists per user.

## Phase 1 — this turn

### 1. Enable Lovable Cloud
- Provisions Postgres + Auth.
- Adds `profiles` table (id, email, full_name, avatar_url, subscription_tier) auto-populated on signup via trigger.
- Adds `subscriptions` table (user_id, stripe_customer_id, stripe_subscription_id, tier, status, current_period_end).

### 2. Real authentication
- **Email + password**: `/signup` and `/login` pages wired to real Supabase auth (current pages are stubs).
- **Google sign-in**: Configured via Lovable's broker — one-click "Continue with Google" button on both pages.
- **Password reset**: `/forgot-password` and `/reset-password` already exist as stubs — wire them to real Supabase calls.
- **Session handling**: `onAuthStateChange` listener at root, router context exposes `auth`, `_authenticated` layout guards `/app/*`.

### 3. Remove demo mode from the entry flow
- Landing page: **"Try Demo" button → "Get started" (signup)**. Sign In button stays.
- Demo banner, demo store seeding on entry, and `/app` demo guard removed.
- Demo dropdown in header replaced with real user menu (name, email, sign out).
- *(Inventory data still uses the in-memory store this turn — that's Phase 2. After signup users land on an empty workspace.)*

### 4. Stripe (BYOK) + 3 paid tiers
- Enable BYOK Stripe integration (you paste `STRIPE_SECRET_KEY`).
- New `/pricing` page with 3 tier cards using your product IDs:
  - **Premium** — `prod_TZS7azSao822lB`
  - **Enterprise** — `prod_SOIVbCCYRWUmKw`
  - **Enterprise+** — `prod_SPTfEc8SmxfHT2`
- Server route `POST /api/checkout` creates a Stripe Checkout Session (mode=subscription) for the chosen product's default price, redirects to Stripe-hosted checkout.
- Server route `POST /api/public/stripe-webhook` verifies signature and updates `subscriptions` table on `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`.
- Server route `POST /api/billing-portal` opens Stripe Customer Portal for self-serve management.
- Settings page gets a "Billing" tab showing current plan + "Manage subscription" button.

### 5. Tier gating
- Free signup gives basic access (catalog browse, limited items).
- Paid tiers unlock advanced features (AI insights, analytics, bulk imports). Soft gating via a `useSubscription()` hook — show "Upgrade" CTA on locked features rather than hiding them.

## Phase 2 — next turn (proposed, not in this plan)
Migrate items, suppliers, locations, purchase orders, requests, movements, notifications from in-memory store → Postgres tables with RLS. This is a ~28-table migration and will be its own focused turn.

## Technical notes

- **Auth gating**: `src/routes/_authenticated.tsx` layout with `beforeLoad` redirect to `/login`. Move all `src/routes/app.*` files under `_authenticated/` directory by adjusting route paths (or wrap inside existing `app.tsx` with the same guard pattern).
- **Stripe webhook secret**: You'll provide both `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET` via the secrets prompt. I'll give you the webhook URL to paste into Stripe Dashboard → Webhooks.
- **Google OAuth**: Configured via `supabase--configure_social_auth` (Lovable broker) — no Google Cloud Console setup needed.
- **What stays demo for now**: The seeded inventory data. Real users will sign in to an empty workspace until Phase 2.

## Files touched (Phase 1)
- New: `_authenticated.tsx` layout, `pricing.tsx`, `api/checkout.ts`, `api/billing-portal.ts`, `api/public/stripe-webhook.ts`, `useSubscription.ts` hook, `BillingSettings.tsx`, migrations for `profiles` + `subscriptions`.
- Modified: `index.tsx` (landing CTAs), `login.tsx`, `signup.tsx`, `forgot-password.tsx`, `reset-password.tsx`, `__root.tsx` (auth context + listener), `Header.tsx` (real user menu), `Sidebar.tsx` (add Billing link), `app.tsx` (remove demo guard).
- Removed/disabled: `DemoBanner`, `enterDemoMode` flow, demo dropdown.

Confirm and I'll start with Phase 1.