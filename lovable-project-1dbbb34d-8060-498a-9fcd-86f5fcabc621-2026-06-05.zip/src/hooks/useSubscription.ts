import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { checkSubscription } from "@/lib/stripe.functions";
import { useAuth } from "@/hooks/useAuth";

export interface SubscriptionState {
  loading: boolean;
  subscribed: boolean;
  tier: "premium" | "enterprise" | "enterprise_plus" | null;
  currentPeriodEnd: string | null;
  refresh: () => void;
}

export function useSubscription(): SubscriptionState {
  const { user } = useAuth();
  const fn = useServerFn(checkSubscription);
  const [state, setState] = useState<Omit<SubscriptionState, "refresh">>({
    loading: false,
    subscribed: false,
    tier: null,
    currentPeriodEnd: null,
  });
  const [nonce, setNonce] = useState(0);

  useEffect(() => {
    if (!user) {
      setState({ loading: false, subscribed: false, tier: null, currentPeriodEnd: null });
      return;
    }
    let cancelled = false;
    setState((s) => ({ ...s, loading: true }));
    fn()
      .then((r) => {
        if (cancelled) return;
        setState({
          loading: false,
          subscribed: r.subscribed,
          tier: r.tier as SubscriptionState["tier"],
          currentPeriodEnd: r.currentPeriodEnd,
        });
      })
      .catch(() => {
        if (cancelled) return;
        setState({ loading: false, subscribed: false, tier: null, currentPeriodEnd: null });
      });
    return () => { cancelled = true; };
  }, [user, fn, nonce]);

  return { ...state, refresh: () => setNonce((n) => n + 1) };
}
