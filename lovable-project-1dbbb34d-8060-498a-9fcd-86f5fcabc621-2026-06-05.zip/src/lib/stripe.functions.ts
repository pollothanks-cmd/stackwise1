import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import Stripe from "stripe";
import { z } from "zod";

export const TIERS = {
  premium: { productId: "prod_TZS7azSao822lB", name: "Premium" },
  enterprise: { productId: "prod_SOIVbCCYRWUmKw", name: "Enterprise" },
  enterprise_plus: { productId: "prod_SPTfEc8SmxfHT2", name: "Enterprise+" },
} as const;

export type Tier = keyof typeof TIERS;

function getStripe() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) throw new Error("STRIPE_SECRET_KEY is not set");
  return new Stripe(key);
}

async function getOrCreateCustomer(stripe: Stripe, email: string, userId: string): Promise<string> {
  const existing = await stripe.customers.list({ email, limit: 1 });
  if (existing.data.length > 0) return existing.data[0].id;
  const created = await stripe.customers.create({ email, metadata: { supabase_user_id: userId } });
  return created.id;
}

/** Create a Stripe Checkout Session for the chosen tier and return the URL. */
export const createCheckoutSession = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      tier: z.enum(["premium", "enterprise", "enterprise_plus"]),
      origin: z.string().url(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { userId } = context;
    const stripe = getStripe();

    // Lookup user email
    const { data: profile } = await supabaseAdmin
      .from("profiles").select("email").eq("id", userId).single();
    if (!profile?.email) throw new Error("User email not found");

    const productId = TIERS[data.tier].productId;
    const prices = await stripe.prices.list({ product: productId, active: true, limit: 1 });
    if (prices.data.length === 0) throw new Error(`No active price for ${data.tier}`);
    const priceId = prices.data[0].id;

    const customerId = await getOrCreateCustomer(stripe, profile.email, userId);

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: "subscription",
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${data.origin}/app/settings?billing=success`,
      cancel_url: `${data.origin}/pricing?canceled=1`,
      metadata: { supabase_user_id: userId, tier: data.tier },
    });

    return { url: session.url };
  });

/** Look up the user's current subscription by querying Stripe directly. */
export const checkSubscription = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { userId } = context;
    const stripe = getStripe();

    const { data: profile } = await supabaseAdmin
      .from("profiles").select("email").eq("id", userId).single();
    if (!profile?.email) return { subscribed: false, tier: null as Tier | null, currentPeriodEnd: null as string | null };

    const customers = await stripe.customers.list({ email: profile.email, limit: 1 });
    if (customers.data.length === 0) {
      await syncSubscription(userId, null);
      return { subscribed: false, tier: null, currentPeriodEnd: null };
    }

    const subs = await stripe.subscriptions.list({
      customer: customers.data[0].id,
      status: "active",
      limit: 1,
    });

    if (subs.data.length === 0) {
      await syncSubscription(userId, null);
      return { subscribed: false, tier: null, currentPeriodEnd: null };
    }

    const sub = subs.data[0];
    const productId = sub.items.data[0].price.product as string;
    const tier = (Object.entries(TIERS).find(([, v]) => v.productId === productId)?.[0] ?? null) as Tier | null;
    const currentPeriodEnd = new Date(sub.items.data[0].current_period_end * 1000).toISOString();

    await syncSubscription(userId, {
      tier,
      status: sub.status,
      stripe_customer_id: customers.data[0].id,
      stripe_subscription_id: sub.id,
      stripe_product_id: productId,
      stripe_price_id: sub.items.data[0].price.id,
      current_period_end: currentPeriodEnd,
      cancel_at_period_end: sub.cancel_at_period_end,
    });

    return { subscribed: true, tier, currentPeriodEnd };
  });

async function syncSubscription(userId: string, sub: {
  tier: Tier | null;
  status: string;
  stripe_customer_id: string;
  stripe_subscription_id: string;
  stripe_product_id: string;
  stripe_price_id: string;
  current_period_end: string;
  cancel_at_period_end: boolean;
} | null) {
  if (!sub) {
    await supabaseAdmin.from("subscriptions").delete().eq("user_id", userId);
    return;
  }
  await supabaseAdmin.from("subscriptions").upsert({ user_id: userId, ...sub }, { onConflict: "user_id" });
}

/** Open the Stripe Customer Portal for subscription management. */
export const openBillingPortal = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ origin: z.string().url() }).parse(input))
  .handler(async ({ data, context }) => {
    const { userId } = context;
    const stripe = getStripe();

    const { data: profile } = await supabaseAdmin
      .from("profiles").select("email").eq("id", userId).single();
    if (!profile?.email) throw new Error("User email not found");

    const customers = await stripe.customers.list({ email: profile.email, limit: 1 });
    if (customers.data.length === 0) throw new Error("No Stripe customer for this user");

    const portal = await stripe.billingPortal.sessions.create({
      customer: customers.data[0].id,
      return_url: `${data.origin}/app/settings`,
    });
    return { url: portal.url };
  });
