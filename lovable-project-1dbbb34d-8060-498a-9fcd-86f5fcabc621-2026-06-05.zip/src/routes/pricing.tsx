import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Package, Check, Loader2, ArrowLeft } from "lucide-react";
import { createCheckoutSession, TIERS, type Tier } from "@/lib/stripe.functions";
import { useAuth } from "@/hooks/useAuth";
import { useSubscription } from "@/hooks/useSubscription";
import { toast } from "sonner";

export const Route = createFileRoute("/pricing")({
  component: PricingPage,
  head: () => ({
    meta: [
      { title: "Pricing — Stackwise" },
      { name: "description", content: "Premium, Enterprise, and Enterprise+ plans for inventory teams of every size." },
    ],
  }),
});

interface PlanCard {
  tier: Tier;
  name: string;
  tagline: string;
  features: string[];
  highlight?: boolean;
}

const PLANS: PlanCard[] = [
  {
    tier: "premium",
    name: TIERS.premium.name,
    tagline: "Everything growing teams need to track stock and stay ahead.",
    features: [
      "Unlimited items & locations",
      "Real-time stock tracking",
      "Purchase orders & receiving",
      "Barcode scanning",
      "Email support",
    ],
  },
  {
    tier: "enterprise",
    name: TIERS.enterprise.name,
    tagline: "Advanced analytics, AI forecasting, and dedicated workflows.",
    features: [
      "Everything in Premium",
      "AI demand forecasting",
      "Advanced analytics & reports",
      "Custom roles & permissions",
      "Priority support",
    ],
    highlight: true,
  },
  {
    tier: "enterprise_plus",
    name: TIERS.enterprise_plus.name,
    tagline: "Full-fledged platform with SSO, audit logs, and SLAs.",
    features: [
      "Everything in Enterprise",
      "SAML SSO",
      "Audit logs & compliance",
      "Custom integrations",
      "Dedicated success manager",
    ],
  },
];

function PricingPage() {
  const { user } = useAuth();
  const { tier: currentTier } = useSubscription();
  const navigate = useNavigate();
  const checkout = useServerFn(createCheckoutSession);
  const [loadingTier, setLoadingTier] = useState<Tier | null>(null);

  async function onSelect(tier: Tier) {
    if (!user) {
      navigate({ to: "/signup" });
      return;
    }
    setLoadingTier(tier);
    try {
      const { url } = await checkout({ data: { tier, origin: window.location.origin } });
      if (url) window.location.href = url;
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Checkout failed");
    } finally {
      setLoadingTier(null);
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6">
          <Link to="/" className="flex items-center gap-2">
            <Package className="h-6 w-6 text-primary" />
            <span className="text-lg font-semibold tracking-tight">Stackwise</span>
          </Link>
          <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Back
          </Link>
        </div>
      </header>

      <section className="px-4 py-16 sm:py-24">
        <div className="mx-auto max-w-3xl text-center">
          <span className="inline-block rounded-md bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">Pricing</span>
          <h1 className="mt-4 text-3xl font-semibold tracking-tight sm:text-4xl lg:text-5xl">
            Plans that scale with your inventory
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-base text-muted-foreground">
            Pick the plan that fits your team. Cancel anytime · billed via Stripe.
          </p>
        </div>

        <div className="mx-auto mt-14 grid max-w-6xl grid-cols-1 gap-6 md:grid-cols-3">
          {PLANS.map((plan) => {
            const isCurrent = currentTier === plan.tier;
            const isLoading = loadingTier === plan.tier;
            return (
              <div
                key={plan.tier}
                className={`flex flex-col rounded-xl border bg-card p-7 transition-all ${
                  plan.highlight ? "border-primary shadow-lg ring-1 ring-primary/20" : "border-border"
                }`}
              >
                {plan.highlight && (
                  <span className="self-start rounded-md bg-primary px-2.5 py-0.5 text-xs font-semibold text-primary-foreground">
                    Most popular
                  </span>
                )}
                <h2 className="mt-3 text-xl font-semibold">{plan.name}</h2>
                <p className="mt-2 text-sm text-muted-foreground">{plan.tagline}</p>
                <ul className="mt-6 space-y-2.5 text-sm">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-7 pt-6 border-t border-border">
                  <button
                    type="button"
                    onClick={() => onSelect(plan.tier)}
                    disabled={isLoading || isCurrent}
                    className={`w-full inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold transition-all disabled:opacity-60 ${
                      plan.highlight
                        ? "bg-primary text-primary-foreground hover:brightness-110"
                        : "border border-border bg-background hover:bg-muted"
                    }`}
                  >
                    {isLoading && <Loader2 className="h-4 w-4 animate-spin" />}
                    {isCurrent ? "Current plan" : user ? "Upgrade" : "Get started"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
